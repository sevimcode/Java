package p1;

public class Acc{
    int p;
    private int q;
    protected int r;
    public int s;
}
