package p3;

import p1.A;     //answer
import p1.p2.B;  // answer

public class C{
    public static void main( String[] args ) {
        A o1 = new A ();
        B o2 = new B () ;
    }



}
