package oca;

public class StringEx3{

    public static void main( String[] args ) {
        String str = " ";
        str.trim ();
        System.out.println (str.equals ("") + " "+ str.isEmpty ());
    }
}
