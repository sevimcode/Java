package oca;

//
//final abstract class A5{  // ABSTRACT CLASS CAN NOT BE FINAL
//
//    protected static int i;
//    void doStuff(){}
//    abstract void doIt;
//
//}

//class A4{
//    protected static final int i;  // NEEDS TO BE INITIALIZED
//    private doStuff(){
//
//    }
//}

//public class A3{
//    private static int i;
//    private A3(){}
//
//}
//

//final class A3{
//    public A3(){
//
//    }
//}




//abstract class A3{
//    private static int i;
//    public void doStuff(){}
//    public A3(){}
//}
