package oca;

public class Circle1 extends Shape{
    private int radius;
    public void draw() {

    }
}





//public abstract class Circle1 extends Shape{
//    private int radius;
//}
