package oca;

public class Capybara extends Rodent{
    public static void main( String[] args ) {
        Rodent rodent = new Capybara ();
        Capybara capybara = (Capybara) rodent;
    }
}
