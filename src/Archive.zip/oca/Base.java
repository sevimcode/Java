package oca;

public class Base{

    public void test(){
        System.out.println("Base");

    }
}
