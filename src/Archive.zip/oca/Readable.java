package oca;

interface Readable extends Downloadable{
    public void readBook();
}
