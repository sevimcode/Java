package oca;

class Tool implements Exportable{
   public void export(){       // weaker access
        System.out.println ("tool export");
    }
}
