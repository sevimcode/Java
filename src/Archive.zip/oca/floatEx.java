package oca;

public class floatEx{

    int y = 203;
    float f = (float)y;
}
