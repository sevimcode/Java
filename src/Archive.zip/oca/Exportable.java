package oca;

interface Exportable{
    void export();
}
