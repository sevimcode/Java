package oca;

public class DerivedA extends Base{

    public void test() {
        System.out.println("DerivedA");

    }
    }
