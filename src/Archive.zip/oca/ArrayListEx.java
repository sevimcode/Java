package oca;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ArrayListEx{

    public static void main( String[] args ) {
        String [] arr = {"Hi" , "How" , "Are" , "you"};
        List <String> arrList = new ArrayList<> ( Arrays.asList ( arr ));
      //  if (arrList.removeIf (String s )-> (return s.length()<=2;)));
      //  System.out.println (s+ "removed");
    }

}// compilation fail no brackets
