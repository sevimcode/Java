package oca;

public class Switch1{

    public static void main( String[] args ) {
        Integer x = new Integer ( "1" );
        switch(x){
            case 1 :
                System.out.println ("one");
                break;
            case 2:
                System.out.println ("two");
                break;
        }
    }


}
