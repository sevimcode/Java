package oca;

public class booleanex{

    public static void main( String[] args ) {
        System.out.println(Boolean.parseBoolean("TRUE"));  // prints true
        System.out.println(new Boolean(null) );         //prints false
    }

} // true false
