package oca;

public class BpolyTest{


    public static void main( String[] args ) {
        Bpoly b = new Bpoly2 ();
        System.out.println (b.getValue ());


        StringBuilder sb = new StringBuilder("shj");
        StringBuilder sb2 = new StringBuilder("shj");
        String s = "hello";




    }
}