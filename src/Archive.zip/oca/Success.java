package oca;

public class Success{
    public static void main( String[] args ) {
        String  arr [] ={"Hello"};
        if (arr[0].equals ("Hello")? false : true ){
            System.out.println ("success");

        }else{
            System.out.println ("failure");
        }
    }
}
