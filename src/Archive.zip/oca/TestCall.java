package oca;

public class TestCall{
    public static void main( String[] args ) {
        Caller c = new Caller ();
        c.start();
      //  c.init();  //private method
    }
} // answer compilation error
