package oca;



public class TestQ20B{

        static double dvalue;
        static TestQ20B ref;

    public static void main( String[] args ) {
        System.out.println (ref);
        System.out.println (dvalue);
    }

    }
// output null
//         0.0
