package oca;

public interface Downloadable{
    public void download();
}
