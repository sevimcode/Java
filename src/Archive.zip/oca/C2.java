package oca;

public class C2{
}
