package oca;

public class Float{
    public static void main( String[] args ) {
        float flt = 100F;
        float flt1 = (float) 1_11.00;
        float flt2 = 100;
        double y1 = 203.22;
      //  float flt3 = y1; you can not put double to float  answer

        int y2 = 100;
        float flt4 = (float) y2;
    }
}
