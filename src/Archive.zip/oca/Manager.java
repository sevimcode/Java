package oca;

public class Manager extends Employee2{

        public int budget;
    }

