package oca;

public class WhileEx2{
    public static void main( String[] args ) {
        int num = 5;
        do{
            System.out.println (num--+" ");
        }while(num==0);
    }
}
