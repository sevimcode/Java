package oca;

public class mainmethodex{

    public static void main( String[] args ) {
        String [] arr = {"Wow", "Mom"};
        System.out.println (arr[1]);
      //  return 0;  compilation fail
    }
}
