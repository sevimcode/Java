package oca;

public class ArrayExeption{

    public static void main( String[] args ) {
//
//        String [] names = {"thomas", "peter", "Joseph"};
//        String [] pwd = new String[3];
//        int idx =0;
//        try {
//            for (String n : names){
//                pwd [idx] = n.substring(2,6);  // when out of bound goes out of the loop catch exception
//                idx++;
//            }
//
//        }
//        catch (Exception e){
//            System.out.println("invalid name");  // first prints an exception
//        }
//        for (String p : pwd){     // then print
//
//            System.out.println(p);
//        }
       }
    }

//    invalid name
//        omas
//        null
//        null

