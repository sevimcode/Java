package oca;

//public class Car extends Vehicle{

//    String trans;
//
//
//    Car( String trans ) {   // line n1
//
//        this.trans = trans;
//    }
//
//    Car( String type , int maxSpeed , String trans ) {
//
//        super ( type , maxSpeed );
//        this ( trans );    // line n2
//
//    }
//
//} // compiler error line n1 and line n2
