package oca;

public interface I{
}
