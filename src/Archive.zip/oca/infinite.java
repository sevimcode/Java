package oca;

public class infinite{

    public static void main( String[] args ) {
        int arr[] = {1,2,3};
        for(int var : arr){
            int i=1;
            while(1<=var);
            System.out.println (i++);
        }
    }
}
