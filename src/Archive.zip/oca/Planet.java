package oca;

public class Planet{


    public static void main( String[] args ) {
        String [] planets = {"mercury", "venus", "earth", "mars"};
        System.out.println (planets.length);
        System.out.println (planets[1].length ());
    }


}
