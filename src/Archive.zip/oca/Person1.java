package oca;

public class Person1{

    String name;
    int age;

    public Person1( String n , int a ) {
        name = n;
        age = a;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

}








