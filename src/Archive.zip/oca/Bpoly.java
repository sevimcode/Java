package oca;

public class Bpoly{

    public Object getValue() { return new Object ();}
}
