package oca;

abstract class Book implements Readable{
    public void readBook(){
        System.out.println ("read book");
    }
}
