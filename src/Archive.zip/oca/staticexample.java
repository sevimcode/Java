package oca;

public class staticexample{
}
