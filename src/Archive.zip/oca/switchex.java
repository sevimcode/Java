package oca;


public class switchex{
    public static void main( String[] args ) {


        final char a = 'A', d = 'D';
        char grade = 'B';

        switch (grade) {


            case 'B':
                System.out.println("great");
            case a:
                System.out.println("fjhdkjhkd");
            case 'C':
                System.out.println("good");
                break;
            case d:
            case 'F':
                System.out.println("not good");

                byte aa =40 , b=50;
          //   byte sum = (byte)  aa + b; //compilation error



        }
    }}