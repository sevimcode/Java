package oca;

public class CheckingAccount1{
    public int amount;
//      public CheckingAccount1(){
//          this.amount =100;
//      }
//    public CheckingAccount1(){
//        amount = 100;
//    }

    public static void main( String[] args ) {
        CheckingAccount1 acct = new CheckingAccount1 ();
     //   acct.amount =100;

        System.out.println (acct.amount);
    }
}
//public CheckingAccount1(){
//          this.amount =100;
//      }
//    public CheckingAccount1(){
//        amount = 100;
//    }
// acct.amount =100;  // this lines set the amount to 100
