package oca;

import replit.Book;

public class TopElement{
    public static void main( String[] args ) {


        int[] stack = { 10 , 20 , 30 };
        int size = 3;
        int idx = 0;

        do {
            idx++;

        }  while(idx<size-1);  // if the condition equals code go out from do while

        System.out.println("top element " + stack[idx]);




    }



}