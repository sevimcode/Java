package oca;

public class Loop{

    public static void main( String[] args ) {
       int i=0;
       int j =7;

        for(i=0 ; i< j-1 ; i=i+2){

            System.out.println(i + " ");
        }
    } // prints 0 2 4
}
