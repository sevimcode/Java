package oca;

public class MissingInfoException extends Exception{
}
