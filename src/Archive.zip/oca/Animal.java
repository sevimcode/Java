package oca;

public class Animal{
    String type = "Canine";
    int maxSpeed = 60;

    Animal () {}
    Animal (String type, int maxSpeed){
        this.type = type;
        this.maxSpeed = maxSpeed ;

    }
}
