package oca;

public class AgeOutOfRangeException extends Exception{
}
