package oca;

public class TrueDone{

    public static void main( String[] args ) {
        String opt = "true";
        switch (opt) {
            case "true":
                System.out.println ( "True" );
                break;
            default:
                System.out.println ( "****" );
        }

        System.out.println ("Done");
        }
    }


// you need to make boolean opt to String opt switch does not accept boolean


