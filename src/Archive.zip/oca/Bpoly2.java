package oca;

public class Bpoly2 extends Bpoly{
    public String getValue() { return "hello";}
}
