package oca;

public class C1{
}
