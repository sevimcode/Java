package oca;

public class MyException extends RuntimeException{






}
