package oca;

public class ArrayQ19B{
    public static void main( String[] args ) {
        int [] xx = null;
        for (int ii : xx){
            System.out.println (ii);
        }
    }
} // nullpointerexception thrown in runtime
