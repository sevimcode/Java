package oca;

public class doWhile{

    public static void main( String[] args ) {
        int num = 5;
        do {
            System.out.println (num-- + " ");

        }while (num == 0);
    }



} // when it comes to while it go out
// prints 5
