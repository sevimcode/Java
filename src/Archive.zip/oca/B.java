package oca;

class B extends A{
    public void test (){
        System.out.println ("B");
    }
}
