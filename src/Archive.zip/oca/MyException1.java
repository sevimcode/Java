package oca;

public class MyException1 extends RuntimeException{
}
