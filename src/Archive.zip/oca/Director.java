package oca;

public class Director extends Manager{
    public int stockOptions;
    }




