package oca;

public class Product1{
    double price;
}
