package oca;

class A{
    public void test (){
        System.out.println ("A");
    }
}
