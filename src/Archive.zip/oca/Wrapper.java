package oca;



public class Wrapper{

    public static void main( String[] args ) {
       byte x=1;
        switch(x){
            case 1 :
                System.out.println("one");
                break;
            case 2:
                System.out.println("two");
                break;



        } // prints 1
    }
}
